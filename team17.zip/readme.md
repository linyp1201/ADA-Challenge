- current optimal code for public testcases except 00, 02:
challenge.cpp
- for testcase 00,02:
challenge_origin.cpp
- compile:
g++ challenge.cpp -o challenge
g++ challenge_origin.cpp -o challenge_origin
